

The letter proposes that ... because ... and ...



community service



don't agree



nosense



riduculous waste time, 