# Task 4

步骤：听力 > 准备 > 答题

特点：无阅读了，难度更大（缺乏预判的文本依据，不过听力文本有如下固定结构）

理解，记录，转述

### 听力

lecture 90-120s

1-2-3个例子，90%是2个例子

听懂80%就可以答出来

#### 固定结构

<img src="https://cdn.jsdelivr.net/gh/davidliuk/images@master/blog/%E6%88%AA%E5%B1%8F2023-06-11%2022.58.44.png" alt="截屏2023-06-11 22.58.44" style="zoom:25%;" />

第一段：背景。听懂为主，作用类似task 3 的阅读，讲关系

第二段：主题1

> 不一定准确的听懂关键词，重点是不能怂，记住读音，到时候说出气势

1. **主题**。首句，记中心词

2. 解释主题。第二句。不重要，不用记

3. **例子**。

   标志词：for ex, instance, say, like，

   记例子

4. 结果

第三段：主题2，结构同一

#### 笔记

四线笔记法：

主题 | 例子 | 结果、

主题 | 例子 | 结果

### 准备 20+30s

整理笔记

### 答题 60s

文章中心说明 10s

In the lecture, the professor is tallking about ...

> 99%的情况下可以直接读屏幕上的内容，即这个的主题

主题1: 25s

The first .… is... (because /which means...)

For example ...

As a result ...

主题2: 25s

The second ... is... (because/ which means...)

For instance ...

As a result ...





---

例题：

resolve conflict

- mediation 

  achieve compromise

  Friend help them to achieve 

- decision

  1 win 2 lose

