# Task 1 独立题

400最大题库，80个最大话题题（免费活动），这80个反复练，会积累很多预料素材，独立题就可以完全没问题

特点：难，容易无话可说，需要积累

背诵：33则语料



二选一：

Personally speaking + 态度 I think + 态度
I agree/disagree + 态度



### 题型辨析

- 二选一：A or B，
- Agree or Disagree

> 选A选B的题，**一定要反对反观点**
>
> 同意不同意的题，不需要反对反观点

改编，语料90%可以用，但也不是都能用，提供一种思路

语法和词汇

注意：

1. 选择题：否定反观点
2. 回答要有例子和细节

### 时间安排

- 15s 准备
- 45s 回答

### 答题模板

Topic sentence 

> 主题句：
>
> - From my perspective/ For me,  
> - I prefer
> - Well, in my opinion, I would definitely agree with the point that ...
> - Personally speaking, I prefer ... for several reasons.
>
> 如果是A or B，主旨句说：选A，however，选B会怎么不好。
>
> 排除其他选项：
>
> However, xxx is xxx, so we may xxx.

Reason

> The first reason I wanna say is that…
>
> TS + Reason 15s

examples and details 30s

> 语料相当于例子和细节
>
> （说否定原因时：穷、没钱是万能原因）
>
> （说小孩时：不成熟、没有自控力、浪费时间）

Reason 2 如果有时间，则reason2和conclusion，没时间就不说

> More importantly, ...

conclusion

>So, that's why I choose ... 



### 备考方案

刷什么题：

1. 当月机经，如果考旧题99.9%的可能在这里面

   只有30多道题

2. 18-22的真题，每天刷10-20个



怎么刷：快速度，多遍数（考前刷个三四遍，抽空闲时间去刷）

一个小时刷10-20道多



语料背熟

尽量多的刷题



刷题：TPO40+的，刷两三次，和当月真题

70% 题是近五年原题

30% 题是新题



模考：换环境模考：在食堂，站着、坐着、倒计时

21-30语料

2 3 4各两个
