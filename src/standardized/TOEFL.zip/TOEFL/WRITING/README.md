# Writing

输入做好就可以28+

- 综合写作 20min

- 独立写作 30min




### 利弊类





### 事实类

标志词：无

与利弊类题目非此即彼



### 独立写作得分点

- 思路，切题

- 结构，固定

- **展开**，快速提分点
- 逻辑，连贯与衔接（重点），一定要每句话都写清楚，语料中强调


上面四个部分都做到了，就可以25+，影响大的就是展开思路（这个需要背语料）

---

- 语言（语法多样性、用词选择），28+




解决写不完的问题：语料

语言

1. 词汇

   四六级词汇

2. 短语 + 句型

   短语素材

3. 文章

   段落版语料

   分类话题范文



短语+例句

Due to the fierce competition in society

The unprecedented envirommental problems are closely associated with 

excessively 过度的

pose a threat to 威胁

having a glimpse of the current situation in education, 

the preferred option

